    <!-- Newsletter -->
        <div class="container mt-5 mb-5">
            <div class="row text-center">
                <div class="col-sm-3">
                    <img width="80" class="img-fluid" src="{{'img/calidad.png'}}">
                    <h5 class="light-gray mt-2 book">Calidad</h5>
                </div>
                   <div class="col-sm-3">
                    <img width="80" class="img-fluid" src="{{'img/facil.png'}}">
                    <h5 class="light-gray mt-2 book">Fácil</h5>

                </div>
                   <div class="col-sm-3">
                    <img width="80" class="img-fluid" src="{{'img/seguridad.png'}}">
                    <h5 class="light-gray mt-2 book">Seguridad</h5>

                </div>
                   <div class="col-sm-3">
                    <img width="80" class="img-fluid" src="{{'img/entrega.png'}}">
                    <h5 class="light-gray mt-2 book">Entrega</h5>

                </div>
            </div>

        </div>
