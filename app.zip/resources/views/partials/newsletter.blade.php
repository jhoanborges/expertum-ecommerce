    <!-- Newsletter -->
        <div class="container mt-5 mb-5">
            <div class="row text-center">
                <div class="col-sm-3">
                    <img width="80" class="img-fluid" src="{{ asset('img/calidad.png') }}">
                    <div>
                        <p>Calidad</p>
                    </div>
                </div>
                   <div class="col-sm-3">
                    <img width="80" class="img-fluid" src="{{ asset('img/facil.png') }}">
                        <div>
                        <p>Fácil</p>
                    </div>
                </div>
                   <div class="col-sm-3">
                    <img width="80" class="img-fluid" src="{{ asset('img/seguridad.png') }}">
                        <div>
                        <p>Seguridad</p>
                    </div>
                </div>
                   <div class="col-sm-3">
                    <img width="80" class="img-fluid" src="{{ asset('img/entrega.png') }}">
                         <div>
                        <p>Entrega</p>
                    </div>
                </div>
            </div>

        </div>
