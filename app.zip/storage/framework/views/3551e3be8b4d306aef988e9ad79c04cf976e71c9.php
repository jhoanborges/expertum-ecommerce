<?php $__env->startSection('content'); ?>
<?php $__env->startSection('extra-css'); ?>
<?php $__env->stopSection(); ?>


<!-- Home -->
<div class="rev_slider_wrapper mt-important">
    <!-- the ID here will be used in the inline JavaScript below to initialize the slider -->
    <div id="rev_slider_1" class="rev_slider fullwidthabanner" data-version="5.4.8" >
        <ul id="slider-content">
            <!-- MINIMUM SLIDE STRUCTURE -->

            <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li data-transition='boxfade' data-link="<?php echo e($slide->link); ?>" data-target="_blank" >

                <img class="img-opacity"src="<?php echo e($slide->url); ?>" alt="<?php echo e($slide->url); ?>"  >
                <!-- BEGIN TEXT LAYER -->
                <div class="tp-caption tp-resizeme large_bold_white"

                data-frames='[{"delay":0,"speed":300,"frame":"0","from":"y:top;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
                data-x="center"
                data-y="center"
                data-hoffset="0"
                data-voffset="0"
                data-width="['auto']"
                data-height="['auto']">
                <div class="myclass text-center">
                    <h1 class="mayus"><?php echo e($slide->name); ?></h1>
                </div>

            </div>
        </li>

        <?php if(!empty($slide->button)): ?>
        <div class="tp-caption lfb ltb start tp-resizeme"

        data-frames='[{"delay":0,"speed":3000,"frame":"0","from":"y:bottom;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":3000,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
        data-x="200"
        data-y="200"
        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
        data-speed="1500"
        data-start="1600"
        data-easing="Power3.easeInOut"
        data-splitin="none"
        data-splitout="none"
        data-elementdelay="0.01"
        data-endelementdelay="0.1"
        data-linktoslide="next"
        style="z-index: 12; max-width: auto; max-height: auto; white-space: nowrap;"><a href='<?php echo e($slide->link); ?>' class='largebtn solid'><?php echo e($slide->button); ?></a> </div>
        <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>
</div>
</div>


<!-- Shop -->

<div class="shop">
    <div class="container-fluid home-padding">
        <div class="row justify-content-center">
            <div class="col-lg-2">

                <!-- Shop Sidebar -->
                <div class="shop_sidebar">
                    <div class="sidebar_section">
                        <div class="row  no-gutters footer_title mayus">
                            <div class="col-sm-6 no-gutters">
                                <span>CATEGORÍAS</span>
                            </div>
                            <div class="col-sm-6 no-gutters text-right">
                                <i class="ti-search pointer"></i>
                            </div>
                        </div>
                        <?php if( $categorias->count() > 0 ): ?>
                        <ul class="sidebar_categories">
                          <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li>
                            <a href="<?php echo e(route('categoria.get', ['cat' => $cat2   , 'categoria' => $category->slug])); ?> "><?php echo e($category->nombrecategoria); ?></a>
                        </li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
                </div>

                <?php if( $top->count() > 0 ): ?>
                <div class="sidebar_section mt-5">
                    <div class="footer_title mayus ">más vendidos</div>
                    <ul class="brands_list">
                        <li class="row no-gutters h-100">

                            <?php $__currentLoopData = $top; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $to): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-12">

                                <a href="<?php echo e(route('product.show' , ['product'=>$to['slug'] ])); ?>" class="d-flex pt-3 pb-3 border-bottom-custom">
                                    <img src="<?php echo e(url(  $to->hasManyImagenes->first()->urlimagen )); ?>" class="top-image img-fluid">

                                    <div class="pmd-card-title pt-0 pb-0 pr-0 align-self-center">
                                        <ul>
                                            <li class="top-sub pmd-card-subtitle-text blue body-text"><?php echo e($to->nombre_producto); ?></li>
                                            
                                            <li class="top-sub pmd-card-subtitle-text blue body-text bold black"><?php echo e('$ '.number_format((float) precioNew($to->slug), 0, ',', '.'  )); ?></li>
                                        </ul>
                                    </div>

                                </a>
                            </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </li>

                    </ul>
                </div>
                <?php endif; ?>
            </div>

        </div>





        <div class="col-lg-10 ">

            <!-- Shop Content -->



            <div class="shop_content ">

                <div class="product_grid">
                    <div class="product_grid_border"></div>

                    <!-- Product Item -->
                    <?php $__currentLoopData = $categorias2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="product_item">
                        <a href="<?php echo e(route('categoria.get', ['cat' => $cat2=1   , 'categoria' => $producto->slug   ])); ?> ">
                            <img class="img-fluid" src="<?php echo e(image($producto->url_imagen)); ?>" alt="">
                            <div class="product_content">
                                <div class="pmd-card-title">
                                    <ul>
                                        <li class="pmd-card-subtitle-text blue category-text"><?php echo e($producto->nombrecategoria); ?></li>
                                    </ul>
                                </div>
                            </div>

                            <ul class="product_marks">
                                <li class="product_mark product_discount">-25%</li>
                                <li class="product_mark product_new">new</li>
                            </ul>
                        </a>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>














                </div>
            </div>

            <!--pagination-->
            <div class="container">
                <div class="row">
                    <?php echo e($categorias2->appends(request()->input() )->links()); ?>

                </div>
            </div>



        </div>
    </div>
</div>

<?php echo $__env->make('partials.newsletter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>



<?php $__env->startSection('extra-js'); ?>
<?php echo $__env->make('partials.js.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).ready(function() {
       $( ".pmd-card" ).hover(
        function() {
            $(this).addClass('shadow').css('cursor', 'pointer');
        }, function() {
            $(this).removeClass('shadow');
        }
        );
// document ready
});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clarashop\resources\views/layouts/home.blade.php ENDPATH**/ ?>