<?php $__env->startSection('content'); ?>

<div class="container mb-3 border-bottom">
    <div class="row">
      <div class="col-lg-12">
        <div class="big-title mayus mb-4 store_title "><b>CONTÁCTANOS</b> </div>
    </div>
</div>


<form class="mb-5" method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-6">

            <p class="bold black mb-2 title-text">Tu opinión cuenta</p>
            <p>Dudas, inquietudes, solicitudes y sugerencias, te invitamos a contárnoslas a través de nuestras líneas de contacto. Te brindaremos toda la información, asesoría, soporte cotizaciones y demostraciones de nuestros productos y servicios</p>

            <div class="form-group">
             <ul>
                <li class="mb-2 centered-li">
                    <img src="<?php echo e(asset('img/location.png')); ?>" class="img-fluid mr-1 img-footer" width="25">
                    <a href="#" class="black">
                    Cra. 26 # 65-54 Of. 401 · Bogotá, D.C.</a>
                </li>
                <li class="mb-2 centered-li">
                    <i class="fab fa-whatsapp light-gray mr-1" style="font-size: 1.4em;"></i>
                    <a href="#" class="black">
                    (315) 690 0996</a>
                </li>
                <li class="mb-2 centered-li">
                    <i class="fas fa-phone light-gray mr-1" style="font-size: 1.2em;"></i>
                    <a href="#" class="black">
                    (300) 696 7118</a>
                </li>

                <li class="mb-2 centered-li">
                    <i class="far fa-envelope light-gray mr-1" style="font-size: 1.2em;"></i>                    
                    <a href="#" class="black">
                    info@expertum.co</a>
                </li>
            </ul>   
        </div>

        <div class="form-group">
            <p class="bold black mb-0 mt-4 title-text">Horario de atención</p>

            <ul>
                <li class="mb-2 centered-li">
                    <i class="far fa-clock light-gray mr-1" style="font-size: 1.4em;"></i>

                    <a href="#" class="black">
                    8:00 am a 6:00pm · Lunes · Viernes</a>
                </li>
                <li class="mb-2 centered-li">
                    <i class="far fa-clock light-gray mr-1" style="font-size: 1.4em;"></i>
                    <a href="#" class="black">
                    10:00am a 4:00pm · Domingo : Festivos </a>
                </li>
            </ul>   
        </div>


    </div>


    <div class="col-md-6">


        <p class="bold black mb-0 title-text">Preguntas y sugerencias</p>


        <div class="form-group mt-2">
            <label class="required bold black">Nombre y Apellido</label>

            <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label class="required bold black">Correo electrónico</label>

            <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label class="required bold black">Mensaje:</label>
            <textarea rows="4" id="message" class="form-control <?php if ($errors->has('message')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('message'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="message" required></textarea>
            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>


        <div class="form-group">
            <button type="submit" class="btn btn-primary w-25">
            Enviar</button>
            </div>


        </div>

    </div>


</form>


</div>

<?php echo $__env->make('partials.newsletter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clarashop\resources\views/layouts/contacto.blade.php ENDPATH**/ ?>