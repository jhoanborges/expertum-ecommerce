
<!DOCTYPE html>
<html lang="en">
<head>
  <title><?php echo e($param->nombre_tienda); ?></title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="OneTech shop project">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php echo $__env->yieldContent('extra-meta'); ?>

  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <link rel="shortcut icon" href="<?php echo e(asset('img/logo-materile.png')); ?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.css')); ?>">
  <link href="<?php echo e(asset('css/fontawesome-all.min.css')); ?>" rel="stylesheet" type="text/css">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/OwlCarousel2-2.2.1/owl.carousel.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/OwlCarousel2-2.2.1/owl.theme.default.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/OwlCarousel2-2.2.1/animate.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/jquery-ui-1.12.1.custom/jquery-ui.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/shop_styles.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/shop_responsive.css')); ?>">

  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/card.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/google-icons.css')); ?>">
  <link href="<?php echo e(asset('css/settings.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('css/themify-icons.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('css/flaticon.css')); ?>" />
  <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('css/checkbox.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('css/toastr.css')); ?>" />

  <link href="<?php echo e(asset('css/captions-original.css')); ?>" rel="stylesheet">

  <?php echo $__env->yieldContent('extra-css'); ?>

  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/custom.css')); ?>">
</head>

<body>
  <div class="super_container">

    <div id="loading">
      <div class="load-circle">
        <span class="one"></span>
      </div>
    </div>

    
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('partials.modalCiudadesSelector', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  </div>

  <script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>

  <script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('styles/bootstrap4/popper.js')); ?>"></script>
  <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('plugins/greensock/TweenMax.min.js')); ?>"></script>
  <script src="<?php echo e(asset('plugins/greensock/TimelineMax.min.js')); ?>"></script>
  <script src="<?php echo e(asset('plugins/scrollmagic/ScrollMagic.min.js')); ?>"></script>
  <script src="<?php echo e(asset('plugins/greensock/animation.gsap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('plugins/greensock/ScrollToPlugin.min.js')); ?>"></script>
  <script src="<?php echo e(asset('plugins/OwlCarousel2-2.2.1/owl.carousel.js')); ?>"></script>
  <script src="<?php echo e(asset('plugins/easing/easing.js')); ?>"></script>
  <script src="<?php echo e(asset('plugins/Isotope/isotope.pkgd.min.js')); ?>"></script>
  <script src="<?php echo e(asset('plugins/jquery-ui-1.12.1.custom/jquery-ui.js')); ?>"></script>
  <script src="<?php echo e(asset('plugins/parallax-js-master/parallax.min.js')); ?>"></script>

  <script src="<?php echo e(url('js/jquery.themepunch.revolution.min.js')); ?>"></script>
  <script src="<?php echo e(url('js/jquery.themepunch.tools.min.js')); ?>"></script>
  <script src="<?php echo e(url('js/jquery.themepunch.plugins.min.js')); ?>"></script>

  
  <script src="<?php echo e(asset('js/global.js')); ?>"></script>
  <script src="<?php echo e(asset('js/checkbox.js')); ?>"></script>
  <script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>

  <script src="<?php echo e(asset('js/shop_custom.js')); ?>"></script>

  <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent('extra-js'); ?>

  <script >

    (function(){

      $("#cart").on("click", function() {
        $(".shopping-cart").fadeToggle( "fast");
      });

    })();


    $(document).ready(function() {
      $('[data-toggle=popover]').popover();
    });
    $(window).on("load", function(){
     document.getElementById("loading").style.display = "none";
   });
 </script>

  <?php echo $__env->make('partials.js.city_selector', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo app('toastr')->render(); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\clarashop\resources\views/welcome.blade.php ENDPATH**/ ?>