<?php $__env->startSection('content'); ?>

<section class="tables mb-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="big-title mayus mb-3 border-bottom-custom">RECUPERA <b>tu contraseña</b> </div>

                <div class="card-body m-5 text-center">
                    <form method="POST" action="<?php echo e(route('password.update')); ?>">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="token" value="<?php echo e($token); ?>">

                        <div class="container">
                            <div class="row d-inline-flex ">

                                <div class="form-group row d-none">
                                    <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                                    <div class="col-md-12">
                                        <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e($email ?? old('email')); ?>" required autocomplete="email" autofocus>

                                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>

                                <div class="col-sm-12 " >
                                    <div class="form-group">
                                        <label class="required bold black">Password</label>
                                        <div class="col-md-12">
                                            <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password" maxlength="191">

                                            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 " >
                                    <div class="form-group">

                                        <label class="required bold black">Confirmar Password</label>
                                        <div class="col-md-12">
                                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password" maxlength="191">
                                        </div>
                                    </div>
                                </div>


                                <div class="col-sm-12 " >
                                    <div class="form-group row text-center">
                                        <div class="col-md-12">
                                            <button type="submit" class="btn btn-primary">
                                                <?php echo e(__('Reestablecer Contraseña')); ?>

                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>



















<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clarashop\resources\views/auth/passwords/reset.blade.php ENDPATH**/ ?>