<?php $__env->startSection('content'); ?>

<div class="container mb-2 border-bottom">
    <div class="row">
      <div class="col-lg-12">
        <div class="big-title mayus mb-4 store_title ">Inicio <b>Iniciar Sesión</b> </div>
    </div>
</div>


<form method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-6">


            <p class="bold black mb-0 title-text">Inicia Sesión</p>
            <p>Ingresa con tu mail y clave de pruebas</p>

            <div class="form-group">
                <label class="bold black">Email</label>

                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <div class="form-group">
                <label class="bold black">Contraseña:</label>
                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="current-password">

                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <div class="form-group">
              <?php if(Route::has('password.request')): ?>
              <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                <?php echo e(__('¿Olvidaste tu contraseña?')); ?>

            </a>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-unlock-alt mr-2"></i>Ingresar</button>
        </div>


    </div>



          <div class="col-md-6">


            <p class="bold black mb-0 title-text">¿Eres nuevo en pruebas?</p>
            <p>Regístrate e nuestro sitio y descubre todas las oportunidades que tenemos para ti.</p>


        <div class="form-group">
            <a href="<?php echo e(route('register')); ?>" class="btn btn-primary">
                <i class="fas fa-user mr-2"></i>Registrarme</a>
        </div>


    </div>







</div>


</form>


</div>




<?php echo $__env->make('partials.newsletter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clarashop\resources\views/auth/login.blade.php ENDPATH**/ ?>