<?php $__env->startSection('extra-css'); ?>
<style >
    .card {
      box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container mb-3 border-bottom">
    <div class="row">
      <div class="col-lg-12">
        <div class="big-title mayus mb-4 store_title"><b>DATOS DE FACTURACIÓN</b></div>
    </div>
</div>


<form class="mb-5" method="POST" action="<?php echo e(route('checkout.store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-5">


            <div class="form-group">
                <label class="required bold black">Nombre(s) y Apellido(s) / Razón Social</label>
                <input id="razon" type="text" class="form-control <?php if ($errors->has('razon')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('razon'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="razon" value="<?php echo e(old('razon')); ?>" required autocomplete="razon" autofocus>

                <?php if ($errors->has('razon')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('razon'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>

            <div class="form-group">
                <label class="required bold black">Tipo de identificación</label>
                <select class="form-control" id="tipo_identificacion" name="tipo_identificacion" required="required">
                    <option disabled selected value="">Seleccione una opción</option>
                    <?php $__currentLoopData = $identificacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option
                    value="<?php echo e($idf->id); ?>" <?php echo e((Auth::user()->tipo_identificacion == $idf->id ) ? ' selected' : ''); ?>

                    ><?php echo e($idf->nombre); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>



        <div class="form-group">
            <label class="required bold black">Número</label>
            <input id="numero" type="text" class="form-control <?php if ($errors->has('numero')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('numero'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="numero" value="<?php echo e(old('numero', Auth::user()->numeroidentificacion )); ?>" required autocomplete="numero" autofocus>

            <?php if ($errors->has('numero')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('numero'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label class="required bold black">Departamento</label>
            <select   required="required"  class="form-control state" name="state" id="state" >
                <option disabled selected value="">Seleccione una opción</option>
                <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($dep->id); ?>"><?php echo e($dep->region); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if ($errors->has('state')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('state'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>


        <div class="form-group">
            <label class="required bold black">Ciudad</label>
            <select class="select2city2 form-control city" name="city" id="city" style="width: 100%" required="required">
            </select>
            <?php if ($errors->has('city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>


        <div class="form-group">
            <label class="bold black">Datos adicionales</label>
            <input id="observaciones" type="text" class="form-control <?php if ($errors->has('observaciones')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('observaciones'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="observaciones" value="<?php echo e(old('observaciones')); ?>" autofocus maxlength="191">

            <?php if ($errors->has('observaciones')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('observaciones'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>



    </div>



    <div class="col-md-5">


        <div class="form-group">
            <label></label>

            <div class="checkbox pmd-default-theme" style="margin-top: 14px;">
                <label class="pmd-checkbox pmd-checkbox-ripple-effect centered-li">
                    <input type="checkbox" value="true" class="border-rounded" name="facturacion">
                    <span>Usar los mismos datos de facturación</span>
                </label>
            </div>
        </div>


        <div class="form-group">
            <label class="required bold black">Email</label>
            <input  type="email" class="form-control" name="email" id="email" value="<?php echo e(old('email',Auth::user()->email )); ?>" required="required" placeholder="Indica el nombre del destinarario">

            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>


        <div class="form-group">
            <label class="required bold black">Dirección de entrega</label>
            <input id="direccion" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="direccion" value="<?php echo e(old('direccion')); ?>" required autofocus>

            <?php if ($errors->has('direccion')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('direccion'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label class="required bold black">Teléfono</label>
            <input id="telefono" type="text" class="form-control <?php if ($errors->has('telefono')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telefono'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="telefono" value="<?php echo e(old('name')); ?>" required  autofocus>

            <?php if ($errors->has('telefono')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telefono'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label class="required bold black">Entregar a: Nombre (s) y Apellido (s) </label>
            <input  type="text" class="form-control" name="entregar" id="entregar" value="<?php echo e(old('entregar', Auth::user()->name .' '. Auth::user()->apellidos )); ?>" required="required" placeholder="Indica el nombre del destinarario">

            <?php if ($errors->has('entregar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('entregar'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="form-group">
            <label></label>

            <div class="checkbox pmd-default-theme">
                <label class="pmd-checkbox pmd-checkbox-ripple-effect centered-li">
                    <input type="checkbox" value="true" class="border-rounded" name="papel_regalo">
                    <span>Empacado en papel de regalo</span>
                </label>
            </div>
        </div>


        <div class="form-group mt-4 mb-4 d-flex justify-content-center">
            <button type="submit" class="btn btn-danger checkout-button">
            Continuar</button>
        </div>




    </div>


    <div class="col-md-2">

      <div class="card p-2">
        <div class="card-content">
            <div class="form-group text-center borders mb-0">
              <img src="<?php echo e(asset('img/cart.png')); ?>" class="img-fluid" width="50">
          </div>
      </div>

      <label class="black text-right  pt-3">Flete $
        <span  type="text" name="flete" id="flete">-------</span>
    </label>


    <label class="bold black text-right pb-2 ">Total $
        <span  type="text" name="total_summary" id="total_summary"><?php echo e(formatPrice(intval($total) )); ?></span>
    </label>

</div>



</div>
</div>


</form>


</div>

<?php echo $__env->make('partials.newsletter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('extra-js'); ?>

<script>
   $(function () {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        type:'post',
        url: "<?php echo e(route('sql_session')); ?>",
        dataType : 'json',
        success:function(res){
            if (res) {

                $('.state').val(res.departamento.id).trigger('change')
                setTimeout(function(){
                    $('.city').val(res.ciudad.id).trigger('change')
                }, 500);
            }
        },
        error: function() {

        }
    })
})

</script>


<script>


    $(function () {

        $('.select2city2').on('select2:select change', function (e) {
            $("#flete").val('');
            var departamento =  $('.select2estado2').val();
            var ciudad = $('.select2city2').val();
            e.preventDefault()
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });


            if (ciudad) {
                $.ajax({
                    type:"POST",
                    data:{
                        state:departamento,
                        city:ciudad,
                    },
                    url:"<?php echo e(route('flete_value')); ?>",

                    beforeSend: function() {
                    },
                    success:function(res){
                        $("#flete").html(parseInt(res).toLocaleString('de-DE',{ minimumFractionDigits: 0 }) )
                        var sum= parseInt('<?php echo e($total); ?>') + parseInt(res)
                        $("#total_summary").html(parseInt(sum).toLocaleString('de-DE',{ minimumFractionDigits: 0 }))
                    }
                });
            }

        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clarashop\resources\views/layouts/checkout.blade.php ENDPATH**/ ?>