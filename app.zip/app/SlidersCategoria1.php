<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SlidersCategoria1 extends Model
{
               protected $table = 'sliders_categoria1s';
    protected $fillable = ['category_id', 'slider_id'];
}
