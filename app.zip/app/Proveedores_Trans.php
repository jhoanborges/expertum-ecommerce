<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Proveedores_Trans extends Model
{
        	 protected $table = 'proveedores_trans';
        	protected $guarded = ['id'];
 		protected $fillable = [];




}
