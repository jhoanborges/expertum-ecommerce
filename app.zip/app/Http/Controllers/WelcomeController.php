<?php

namespace App\Http\Controllers;

Use Alert;
use DB;
use App\Category;
use Session;
use Illuminate\Http\Request;
use App\Productomodelo;
use App\Imgproductomodelo;
use App\Categorian1modelo;
use App\Categorian2modelo;
use App\Categorian3modelo;
use App\Categorian4modelo;
use App\Categorian5modelo;
use App\Imagenpromomodelo;
use App\Trmmodelo;
use Validator;
use Gloudemans\Shoppingcart\Facades\Cart;

class WelcomeController extends Controller
{

}
