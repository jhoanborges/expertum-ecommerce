<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ePayco extends Model
{
            protected $table = 'e_paycos';
    protected $fillable = [];
    protected $guarded = ['id'];
}
