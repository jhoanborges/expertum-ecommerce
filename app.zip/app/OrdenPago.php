<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrdenPago extends Model
{
            	 protected $table = 'orden_pago';
        	protected $guarded = ['id'];
 		protected $fillable = [];
}
