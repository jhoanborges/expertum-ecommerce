<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transportadores extends Model
{
            protected $table = 'transportadores';
        protected $guarded = ['id'];
 		protected $fillable = [];
}
