<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NewOrdenPago extends Model
{
    //
}
