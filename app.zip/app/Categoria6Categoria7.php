<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Categoria6Categoria7 extends Model
{
    protected $table = 'categoria6_categoria7';
    protected $fillable = ['categoria7_id', 'categoria6_id'];
}
