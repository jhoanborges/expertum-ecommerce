<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Subtitulos extends Model
{
            protected $table = 'subtitulos';
        protected $guarded = ['id'];
 		protected $fillable = [];
}
