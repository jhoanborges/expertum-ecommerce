<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pasarelas extends Model
{
    	 protected $table = 'pasarelas';
        	protected $guarded = ['id'];
 		protected $fillable = [];

}
