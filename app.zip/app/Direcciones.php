<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Direcciones extends Model
{
        protected $table = 'direcciones';
        protected $guarded = ['id'];
 		protected $fillable = [];
}
