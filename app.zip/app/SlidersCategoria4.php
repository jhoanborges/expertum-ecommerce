<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SlidersCategoria4 extends Model
{
                   protected $table = 'sliders_categoria4s';
    protected $fillable = ['category_id', 'slider_id'];
}
