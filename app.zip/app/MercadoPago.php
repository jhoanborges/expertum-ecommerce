<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MercadoPago extends Model
{
            	 protected $table = 'mercado_pagos';
        	protected $guarded = ['id'];
 		protected $fillable = [];
}
