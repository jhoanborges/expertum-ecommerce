<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SlidersCategoria3 extends Model
{
                   protected $table = 'sliders_categoria3s';
    protected $fillable = ['category_id', 'slider_id'];
}
